// Package dirent parses raw syscall dirents
package dirent
